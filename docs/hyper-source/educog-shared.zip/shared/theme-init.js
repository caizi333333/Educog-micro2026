/* Apply persisted theme + accent ASAP (before paint) */
(function () {
  try {
    const t = localStorage.getItem("educog-theme") || "dark";
    const a = localStorage.getItem("educog-accent") || "cyan";
    document.documentElement.setAttribute("data-theme", t);
    document.documentElement.setAttribute("data-accent", a);
  } catch (e) {}
})();
