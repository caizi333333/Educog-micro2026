/* ============================================================
   EduCog-Micro · Shared React Components
   载入顺序：React → Babel → tokens.css → lucide → 本文件 → page
   ============================================================ */

const { useState, useEffect, useRef, useMemo, useCallback } = React;
const L = window.lucide || {};

/* ---- Icon wrapper over lucide (inline SVG strokes) ---- */
function Icon({ name, size = 16, className = "", strokeWidth = 1.75, style }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || !window.lucide) return;
    ref.current.innerHTML = "";
    const el = window.lucide.createElement(window.lucide.icons[name] || window.lucide.icons.Circle);
    el.setAttribute("width", size);
    el.setAttribute("height", size);
    el.setAttribute("stroke-width", strokeWidth);
    ref.current.appendChild(el);
  }, [name, size, strokeWidth]);
  return <span ref={ref} className={`ec-icon ${className}`} style={{ display: "inline-flex", ...style }} />;
}

/* ---- Top bar (应用全局顶栏) ---- */
function TopBar({ title, breadcrumb = [], right, theme, setTheme }) {
  return (
    <header style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      height: 48, padding: "0 16px",
      background: "var(--bg-panel)",
      borderBottom: "1px solid var(--border-subtle)",
      flexShrink: 0,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <Brandmark size={22} />
        <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
          <span style={{ color: "var(--text-secondary)", fontWeight: 500 }}>EduCog·芯智育才</span>
          {breadcrumb.map((b, i) => (
            <React.Fragment key={i}>
              <span style={{ color: "var(--text-tertiary)" }}>/</span>
              <span style={{ color: i === breadcrumb.length - 1 ? "var(--text-primary)" : "var(--text-secondary)" }}>{b}</span>
            </React.Fragment>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        {right}
        {setTheme && (
          <button className="btn icon sm" title="切换主题" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            <Icon name={theme === "dark" ? "Sun" : "Moon"} size={14} />
          </button>
        )}
        <div style={{
          width: 28, height: 28, borderRadius: 4,
          background: "var(--accent-soft)", border: "1px solid var(--accent-line)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--accent-hover)", fontSize: 11, fontWeight: 600, fontFamily: "var(--font-mono)",
        }}>ZH</div>
      </div>
    </header>
  );
}

/* ---- Brand mark (logo) ---- */
function Brandmark({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ display: "block" }}>
      <rect x="2.5" y="2.5" width="19" height="19" rx="2" stroke="var(--accent)" strokeWidth="1.5" />
      <rect x="6" y="6" width="12" height="12" rx="1" fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="1" />
      <circle cx="6" cy="6" r="0.8" fill="var(--accent)" />
      <circle cx="18" cy="6" r="0.8" fill="var(--accent)" />
      <circle cx="6" cy="18" r="0.8" fill="var(--accent)" />
      <circle cx="18" cy="18" r="0.8" fill="var(--accent)" />
      <path d="M9 10h6M9 12h6M9 14h4" stroke="var(--accent-hover)" strokeWidth="0.8" strokeLinecap="round" />
      <path d="M2.5 8h2M2.5 12h2M2.5 16h2M19.5 8h2M19.5 12h2M19.5 16h2M8 2.5v2M12 2.5v2M16 2.5v2M8 19.5v2M12 19.5v2M16 19.5v2"
        stroke="var(--accent)" strokeWidth="1" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

/* ---- Status dot with pulse ---- */
function StatusDot({ color = "var(--success)", pulse = false, label }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--text-secondary)" }}>
      <span style={{
        width: 8, height: 8, borderRadius: "50%", background: color,
        boxShadow: pulse ? `0 0 0 0 ${color}` : "none",
        animation: pulse ? "pulse 1.8s infinite" : "none",
      }} />
      {label}
    </span>
  );
}

/* ---- SectionHeader ---- */
function SectionHeader({ icon, title, desc, right }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "10px 14px",
      borderBottom: "1px solid var(--border-subtle)",
      background: "var(--bg-panel)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {icon && <Icon name={icon} size={14} style={{ color: "var(--accent)" }} />}
        <div>
          <div style={{ fontSize: 12, fontWeight: 600, color: "var(--text-primary)", letterSpacing: "0.02em", textTransform: "uppercase", fontFamily: "var(--font-mono)" }}>{title}</div>
          {desc && <div style={{ fontSize: 11, color: "var(--text-tertiary)", marginTop: 2 }}>{desc}</div>}
        </div>
      </div>
      {right}
    </div>
  );
}

/* ---- Tag ---- */
function Tag({ children, tone = "default", icon }) {
  return (
    <span className={`tag ${tone !== "default" ? tone : ""}`}>
      {icon && <Icon name={icon} size={11} />}
      {children}
    </span>
  );
}

/* ---- 8051 DIP-40 Chip SVG (reused across pages) ---- */
function Chip8051({ width = 260, activePins = [], label = "AT89C52" }) {
  const pins = Array.from({ length: 40 }, (_, i) => i + 1);
  const pinNames = {
    1: "P1.0", 2: "P1.1", 3: "P1.2", 4: "P1.3", 5: "P1.4", 6: "P1.5", 7: "P1.6", 8: "P1.7",
    9: "RST", 10: "P3.0/RXD", 11: "P3.1/TXD", 12: "P3.2", 13: "P3.3", 14: "P3.4", 15: "P3.5", 16: "P3.6", 17: "P3.7",
    18: "XTAL2", 19: "XTAL1", 20: "GND",
    21: "P2.0", 22: "P2.1", 23: "P2.2", 24: "P2.3", 25: "P2.4", 26: "P2.5", 27: "P2.6", 28: "P2.7",
    29: "PSEN", 30: "ALE", 31: "EA", 32: "P0.7", 33: "P0.6", 34: "P0.5", 35: "P0.4", 36: "P0.3", 37: "P0.2", 38: "P0.1", 39: "P0.0", 40: "VCC",
  };
  const H = 360, W = 160, PR = 12;
  return (
    <svg width={width} viewBox={`0 0 ${W + 120} ${H}`} style={{ display: "block" }}>
      <rect x="60" y="10" width={W} height={H - 20} rx="3" fill="#0a0a0a" stroke="#2a2a2a" strokeWidth="1" />
      <circle cx={60 + W / 2} cy="28" r="5" fill="none" stroke="#444" strokeWidth="0.8" />
      <text x={60 + W / 2} y={H / 2 - 10} textAnchor="middle" fill="#e6eaf0" fontFamily="var(--font-mono)" fontSize="13" fontWeight="600">{label}</text>
      <text x={60 + W / 2} y={H / 2 + 8} textAnchor="middle" fill="#6b7483" fontFamily="var(--font-mono)" fontSize="9">8-bit MCU · 40-DIP</text>
      <text x={60 + W / 2} y={H / 2 + 24} textAnchor="middle" fill="#6b7483" fontFamily="var(--font-mono)" fontSize="8">11.0592 MHz</text>
      {pins.map((p) => {
        const isLeft = p <= 20;
        const idx = isLeft ? p - 1 : 40 - p;
        const y = 26 + idx * ((H - 52) / 19);
        const active = activePins.includes(p);
        return (
          <g key={p}>
            <rect
              x={isLeft ? 46 : 60 + W}
              y={y - 5} width="14" height="10"
              fill={active ? "var(--accent)" : "#b8b8b8"}
              stroke="#555" strokeWidth="0.5"
            />
            <text
              x={isLeft ? 42 : 60 + W + 18}
              y={y + 3}
              textAnchor={isLeft ? "end" : "start"}
              fill={active ? "var(--accent-hover)" : "#a8b1c0"}
              fontFamily="var(--font-mono)" fontSize="8"
            >
              {pinNames[p]}
            </text>
            <text
              x={isLeft ? 68 : 52 + W}
              y={y + 3}
              textAnchor={isLeft ? "start" : "end"}
              fill="#555"
              fontFamily="var(--font-mono)" fontSize="7"
            >{p}</text>
          </g>
        );
      })}
    </svg>
  );
}

/* ---- Difficulty indicator ---- */
function Difficulty({ level = 1 }) {
  // 1..5
  return (
    <span style={{ display: "inline-flex", gap: 2, alignItems: "center" }}>
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} style={{
          width: 4, height: 10,
          background: i <= level ? "var(--accent)" : "var(--border-default)",
          borderRadius: 1,
        }} />
      ))}
      <span style={{ marginLeft: 6, fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--text-tertiary)" }}>
        L{level}
      </span>
    </span>
  );
}

/* ---- Global pulse animation ---- */
const globalStyleEl = document.createElement("style");
globalStyleEl.textContent = `
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 currentColor; }
  70% { box-shadow: 0 0 0 8px transparent; }
  100% { box-shadow: 0 0 0 0 transparent; }
}
@keyframes shimmer {
  0% { opacity: 0.5; } 50% { opacity: 1; } 100% { opacity: 0.5; }
}
@keyframes slideIn {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}
.fade-in { animation: slideIn 240ms var(--ease-out) both; }
`;
document.head.appendChild(globalStyleEl);

/* Export to global */
Object.assign(window, {
  Icon, TopBar, Brandmark, StatusDot, SectionHeader, Tag, Chip8051, Difficulty,
});
