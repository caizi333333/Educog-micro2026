/* Medal system — shared data + Medal SVG component
   Style: 几何盾牌 + 金属带绶带 (medal_visual = 4 metallic + 3 shield blended)
   Levels: 1-10 numeric tiers (1-3 铜, 4-6 银, 7-9 金, 10 钻) */

const MEDAL_TIERS = [
  { lv: 1,  name: "铜·I",   metal: "bronze", grad: ["#9c5a2c", "#ffb273"] },
  { lv: 2,  name: "铜·II",  metal: "bronze", grad: ["#a35e2c", "#ffba7a"] },
  { lv: 3,  name: "铜·III", metal: "bronze", grad: ["#a86430", "#ffc488"] },
  { lv: 4,  name: "银·I",   metal: "silver", grad: ["#7d8690", "#e6ecf2"] },
  { lv: 5,  name: "银·II",  metal: "silver", grad: ["#838c97", "#eef2f6"] },
  { lv: 6,  name: "银·III", metal: "silver", grad: ["#8a939e", "#f4f6fa"] },
  { lv: 7,  name: "金·I",   metal: "gold",   grad: ["#a87a18", "#ffe28a"] },
  { lv: 8,  name: "金·II",  metal: "gold",   grad: ["#b88318", "#ffe892"] },
  { lv: 9,  name: "金·III", metal: "gold",   grad: ["#c88a18", "#ffeea0"] },
  { lv: 10, name: "钻",     metal: "diamond",grad: ["#3aa8ff", "#dcf3ff"] },
];

function tierOf(lv) { return MEDAL_TIERS[Math.max(0, Math.min(9, lv - 1))]; }

const MEDAL_CATEGORIES = [
  { id: "mastery",  label: "掌握度", color: "var(--success)", icon: "Target" },
  { id: "progress", label: "进度",   color: "var(--accent)",  icon: "TrendingUp" },
  { id: "skill",    label: "技能",   color: "var(--accent-hover)", icon: "Cpu" },
  { id: "habit",    label: "习惯",   color: "var(--amber)",   icon: "Calendar" },
  { id: "explore",  label: "探索",   color: "oklch(70% 0.15 320)", icon: "Compass" },
  { id: "teacher",  label: "教师授予", color: "oklch(70% 0.18 30)", icon: "Award" },
];

/* All medals — earned: lv >= 1, lv = 0 means locked */
const MEDALS = [
  // 掌握度
  { id: "M-001", cat: "mastery", title: "知识点新手",   desc: "首个知识点掌握度达到 80%", lv: 8,  earned: "2025-09-12", req: "掌握度 ≥80%", icon: "Target" },
  { id: "M-002", cat: "mastery", title: "连续满分",     desc: "连续 5 次测验获得满分",     lv: 5,  earned: "2025-09-28", req: "5 连满分", icon: "Crosshair" },
  { id: "M-003", cat: "mastery", title: "全章精通",     desc: "整章知识点全部 ≥80%",       lv: 6,  earned: "2025-10-15", req: "章节平均 ≥80%", icon: "ShieldCheck" },
  { id: "M-004", cat: "mastery", title: "学神",         desc: "全部知识点平均 ≥90%",       lv: 0,  prog: 62, req: "总平均 ≥90%", icon: "Sparkles" },
  { id: "M-005", cat: "mastery", title: "零失误",       desc: "单次测验 100% 正确率",      lv: 4,  earned: "2025-09-22", req: "测验满分", icon: "Check" },

  // 进度
  { id: "M-101", cat: "progress", title: "首次启程",     desc: "完成第一个实验",            lv: 3,  earned: "2025-09-05", req: "完成 LAB-01", icon: "Rocket" },
  { id: "M-102", cat: "progress", title: "周次达人",     desc: "按时完成本周全部任务",      lv: 5,  earned: "2025-10-08", req: "本周任务清零", icon: "CalendarCheck" },
  { id: "M-103", cat: "progress", title: "I/O 章节通关", desc: "完成 I/O 端口章节全部实验", lv: 6,  earned: "2025-10-12", req: "章节实验全完成", icon: "Flag" },
  { id: "M-104", cat: "progress", title: "学期半程",     desc: "完成 8 周课程内容",         lv: 7,  earned: "2025-10-25", req: "≥8 周完成", icon: "Hourglass" },
  { id: "M-105", cat: "progress", title: "全勤毕业",     desc: "完成全部 16 周课程",        lv: 0,  prog: 56, req: "16 周全完成", icon: "GraduationCap" },
  { id: "M-106", cat: "progress", title: "首次仿真",     desc: "首次成功运行仿真",          lv: 2,  earned: "2025-09-06", req: "首次仿真成功", icon: "Play" },

  // 技能
  { id: "M-201", cat: "skill", title: "GPIO 大师",       desc: "GPIO 相关实验全部 ≥80%",     lv: 7,  earned: "2025-10-02", req: "LAB-01~03 ≥80%", icon: "Cable" },
  { id: "M-202", cat: "skill", title: "定时器王者",      desc: "T0/T1/中断 实验全部完成",    lv: 0,  prog: 30, req: "LAB-04~05 ≥80%", icon: "Timer" },
  { id: "M-203", cat: "skill", title: "UART 通信员",     desc: "完成串口通信实验",           lv: 0,  prog: 0,  req: "LAB-09 ≥80%", icon: "Radio" },
  { id: "M-204", cat: "skill", title: "ADC 调音师",      desc: "完成 ADC 采集实验",          lv: 0,  prog: 0,  req: "LAB-10 ≥80%", icon: "AudioWaveform" },
  { id: "M-205", cat: "skill", title: "传感器猎人",      desc: "完成 5 种以上传感器实验",    lv: 0,  prog: 20, req: "≥5 种传感器", icon: "Thermometer" },
  { id: "M-206", cat: "skill", title: "汇编工匠",        desc: "提交 ≥3 份汇编代码作业",     lv: 4,  earned: "2025-10-18", req: "≥3 份汇编", icon: "Hammer" },

  // 习惯
  { id: "M-301", cat: "habit", title: "7 日打卡",        desc: "连续 7 天登录学习",          lv: 3,  earned: "2025-09-12", req: "连续 7 天", icon: "Calendar" },
  { id: "M-302", cat: "habit", title: "30 日打卡",       desc: "连续 30 天登录学习",         lv: 6,  earned: "2025-10-05", req: "连续 30 天", icon: "CalendarRange" },
  { id: "M-303", cat: "habit", title: "100 日马拉松",    desc: "累计登录 100 天",            lv: 0,  prog: 48, req: "累计 100 天", icon: "Footprints" },
  { id: "M-304", cat: "habit", title: "守时学者",        desc: "连续 5 次按时提交作业",      lv: 4,  earned: "2025-10-10", req: "5 次按时", icon: "Clock" },
  { id: "M-305", cat: "habit", title: "深夜程序员",      desc: "凌晨 0–4 点提交作业 ≥3 次",  lv: 2,  earned: "2025-09-30", req: "深夜提交 ≥3", icon: "Moon" },
  { id: "M-306", cat: "habit", title: "晨读者",          desc: "早 6–8 点学习 ≥5 次",        lv: 0,  prog: 60, req: "晨读 ≥5 次", icon: "Sunrise" },

  // 探索
  { id: "M-401", cat: "explore", title: "自由探索者",    desc: "进入自由模式仿真",           lv: 3,  earned: "2025-09-20", req: "自由模式 ≥1 次", icon: "Compass" },
  { id: "M-402", cat: "explore", title: "扩展任务",      desc: "完成 ≥1 个扩展实验",         lv: 5,  earned: "2025-10-12", req: "扩展实验 ≥1", icon: "Puzzle" },
  { id: "M-403", cat: "explore", title: "团队协作",      desc: "参与小组协作实验 ≥1 次",     lv: 4,  earned: "2025-10-20", req: "协作 ≥1", icon: "Users" },
  { id: "M-404", cat: "explore", title: "代码之巅",      desc: "提交超过课程要求的扩展代码", lv: 0,  prog: 0,  req: "扩展代码 ≥1", icon: "Mountain" },
  { id: "M-405", cat: "explore", title: "提问大师",      desc: "在论坛累计提问 ≥10 次",      lv: 0,  prog: 40, req: "提问 ≥10", icon: "MessageCircleQuestion" },

  // 教师授予
  { id: "M-501", cat: "teacher", title: "课堂之星",      desc: "由教师在课堂上授予",         lv: 7,  earned: "2025-10-09", req: "教师手动授予", icon: "Star", teacher: "李老师" },
  { id: "M-502", cat: "teacher", title: "最佳报告",      desc: "实验报告评为最佳",           lv: 0,  prog: 0,  req: "教师评定", icon: "FileText" },
  { id: "M-503", cat: "teacher", title: "助教推荐",      desc: "助教推荐学习榜样",           lv: 0,  prog: 0,  req: "助教提名", icon: "UserCheck" },
  { id: "M-504", cat: "teacher", title: "院系荣誉",      desc: "代表班级或院系参赛",         lv: 0,  prog: 0,  req: "教师提名", icon: "Trophy" },
];

function medalPoints(m) { return m.lv > 0 ? m.lv * 10 : 0; }

/* ================ Medal SVG (geometric shield + metallic ribbon) ================ */
function MedalSVG({ medal, size = 96, locked = false }) {
  const t = tierOf(medal.lv || 1);
  const isLocked = locked || !medal.lv;
  const id = `m-${medal.id}-${size}`;
  const W = size, H = size * 1.18;
  const cx = W / 2;

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ overflow: "visible", display: "block" }}>
      <defs>
        <radialGradient id={`grad-${id}`} cx="35%" cy="30%" r="80%">
          <stop offset="0%" stopColor={isLocked ? "#3a4250" : t.grad[1]} />
          <stop offset="55%" stopColor={isLocked ? "#262b34" : t.grad[0]} />
          <stop offset="100%" stopColor={isLocked ? "#1a1d24" : t.grad[0]} stopOpacity="0.85" />
        </radialGradient>
        <linearGradient id={`ring-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={isLocked ? "#4a5260" : t.grad[1]} />
          <stop offset="100%" stopColor={isLocked ? "#2a2e38" : t.grad[0]} />
        </linearGradient>
      </defs>

      {/* Ribbons */}
      {!isLocked && (
        <g opacity="0.92">
          <polygon points={`${cx - W*0.32},${H*0.55} ${cx - W*0.18},${H*0.55} ${cx - W*0.10},${H*0.95} ${cx - W*0.24},${H*0.85} ${cx - W*0.32},${H*0.95}`}
            fill={t.grad[0]} stroke={t.grad[1]} strokeWidth="0.6" />
          <polygon points={`${cx + W*0.32},${H*0.55} ${cx + W*0.18},${H*0.55} ${cx + W*0.10},${H*0.95} ${cx + W*0.24},${H*0.85} ${cx + W*0.32},${H*0.95}`}
            fill={t.grad[0]} stroke={t.grad[1]} strokeWidth="0.6" opacity="0.85" />
        </g>
      )}

      {/* Shield body — hexagonal */}
      <polygon
        points={`${cx},${H*0.10} ${cx + W*0.34},${H*0.25} ${cx + W*0.34},${H*0.55} ${cx},${H*0.78} ${cx - W*0.34},${H*0.55} ${cx - W*0.34},${H*0.25}`}
        fill={`url(#grad-${id})`}
        stroke={`url(#ring-${id})`}
        strokeWidth="2"
        style={!isLocked ? { filter: `drop-shadow(0 4px 12px ${t.grad[0]}66)` } : {}}
      />
      {/* Inner stroke */}
      <polygon
        points={`${cx},${H*0.16} ${cx + W*0.27},${H*0.28} ${cx + W*0.27},${H*0.53} ${cx},${H*0.71} ${cx - W*0.27},${H*0.53} ${cx - W*0.27},${H*0.28}`}
        fill="none"
        stroke={isLocked ? "#3a4250" : t.grad[1]}
        strokeWidth="0.8"
        opacity="0.5"
      />

      {/* Glyph */}
      <g transform={`translate(${cx}, ${H*0.42})`}>
        <foreignObject x={-size*0.18} y={-size*0.18} width={size*0.36} height={size*0.36}>
          <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: isLocked ? "#5a6270" : "#0a0e14" }}>
            <Icon name={medal.icon || "Award"} size={size * 0.28} strokeWidth={2.2} />
          </div>
        </foreignObject>
      </g>

      {/* Level badge */}
      <g>
        <circle cx={cx + W*0.28} cy={H*0.18} r={size * 0.13}
          fill={isLocked ? "#1a1d24" : "#0a0e14"}
          stroke={isLocked ? "#3a4250" : t.grad[1]}
          strokeWidth="1.5"
        />
        <text x={cx + W*0.28} y={H*0.18 + size*0.05}
          textAnchor="middle"
          fontSize={size * 0.16}
          fontWeight="700"
          fontFamily="var(--font-mono)"
          fill={isLocked ? "#5a6270" : t.grad[1]}
        >{medal.lv || "?"}</text>
      </g>

      {/* Lock overlay */}
      {isLocked && (
        <g transform={`translate(${cx - 8}, ${H*0.42 - 8})`}>
          <rect x="0" y="6" width="16" height="12" rx="2" fill="#3a4250" />
          <path d="M 3 6 V 4 a 5 5 0 0 1 10 0 V 6" stroke="#3a4250" strokeWidth="2" fill="none" />
        </g>
      )}
    </svg>
  );
}

window.MEDAL_TIERS = MEDAL_TIERS;
window.MEDAL_CATEGORIES = MEDAL_CATEGORIES;
window.MEDALS = MEDALS;
window.tierOf = tierOf;
window.medalPoints = medalPoints;
window.MedalSVG = MedalSVG;
